<?Php include 'header.php'?>

<div class="container">
    <div class="jumbotron">
        <h1>I am Antony The Php Guy</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus,
            architecto blanditiis cumque itaque nesciunt obcaecati quae quibusdam
            recusandae reiciendis suscipit, unde vero. Ab corporis culpa et fugiat
            nam nesciunt numquam.
        </p>
    </div>
</div>

<div class="bg_img" style="background-image: url('./static/images/img11.png')">
    <p style="color: #ffffff;text-align: center;padding-top: 40px" class="lead" >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque
        laboriosam sint voluptatum. Accusantium amet, debitis distinctio
    </p>
</div>

   <?php
    session_start();
   $firstname = $_SESSION['firstname'];
   $lastname = $_SESSION['lastname'];
   $email = $_SESSION['email'];
   $password = $_SESSION['password'];
        echo "<h1>$firstname</h1>";
   ?>

<h1><?php echo $_SESSION['firstname']?></h1>

<?Php include 'footer.php'?>
