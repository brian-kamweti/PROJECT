<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 6/18/19
 * Time: 12:06 PM
 */


    session_start();
        $a = $_SESSION['x'];
        $b = $_SESSION['y'];

        echo $a." ". $b;



?>