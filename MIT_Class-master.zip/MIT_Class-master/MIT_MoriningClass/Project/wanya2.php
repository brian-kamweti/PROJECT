<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 6/18/19
 * Time: 11:56 AM
 */

if (isset($_POST['btn_submit'])){
    session_start();
    $jina = $_POST['name'];
    $arafa = $_POST['mail'];


    $_SESSION['x'] = $jina;
    $_SESSION['y'] = $arafa;

    header('location:wanya3.php');


}



?>