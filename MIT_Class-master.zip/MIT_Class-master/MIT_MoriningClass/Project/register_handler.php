<?php
$firstname=$lastname=$email=$password='';

if (isset($_POST['save'])){
    ;
    if(isset($_POST['firstname'])){
        $firstname = $_POST['firstname'];
    }
    if(isset($_POST['lastname'])){
        $lastname = $_POST['lastname'];
    }
    if(isset($_POST['email'])){
        $email = $_POST['email'];
    }
    if(isset($_POST['password'])){
        $password = $_POST['password'];
    }

}


//global $firstname,$lastname,$email,$password;
session_start();
$_SESSION['firstname'] = $firstname;
$_SESSION['lastname'] = $lastname;
$_SESSION['email'] = $email;
$_SESSION['password'] = $password;

header('location:index.php');

?>

