<?php
?>

grab data from the register.php and login.php, validate the data and dislay it in
the index page, in form of a table.
