<div class="navbar navbar-inverse navbar-fixed-bottom">
    <ul>
        <a href="#">Facebook</a>
        <a href="#">Github</a>
    </ul>
</div>
</body>
</html>