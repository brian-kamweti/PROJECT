<?Php include 'header.php'?>

<?php
    if(isset($_GET['f_error'])){
        echo "First name is required";
    }
?>




    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-3">
            <form action="register_handler.php" method="post">
                <div class="form-group">
                    <label for="firstname">Firstname</label>
                    <span class="btn-danger">
                        <?php
                            if(isset($_GET['f_error'])){
                                echo "First name is required";
                            }
                        ?>
                    </span>
                    <input type="text" class="form-control" id="firstname" name="firstname">
                </div>
                <div class="form-group">
                    <label for="firstname">Lastname</label>
                    <input type="text" class="form-control" id="email" name="lastname">
                </div>
                <div class="form-group">
                    <label for="email">Email address:</label>
                    <input type="email" class="form-control" id="email">
                </div>
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" id="pwd" name="password_1">
                </div>
                <div class="form-group">
                    <label for="pwd">Confirm Password:</label>
                    <input type="password" class="form-control" id="pwd" name="password_2">
                </div>
                <div class="checkbox">
                    <label><input type="checkbox"> Remember me</label>
                </div>
                <button type="submit" class="btn btn-default" name="save">Submit</button>
            </form>
        </div>
        <div class="col-md-3"></div>
    </div>
<?Php include 'footer.php'?>