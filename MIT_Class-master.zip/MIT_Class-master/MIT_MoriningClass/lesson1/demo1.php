<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 5/30/19
 * Time: 10:59 AM
 */
echo "Hello world";
echo "<h1>Hello world!</h1>";

//php case sensitivity
//Key words in php are case insensitive
//e.g if, echo, while, print
ECHO "<h1>Hello world!</h1>";
//variables are case sensitive
//name, Name not the same












?>

