<?php
#an array is a special variable which can hold more than one value at a time
//types
//1.indexed
//2.associative array
//3.Multudimensional array
$benz = "benz";
$volvo = "volvo";
$audi = "audi";
//syntax
//$arrayname = array('item1', 'item2', 'item3')
$cars = array('benz', 'volvo','audi');

#accessing items in an array
//syntax
//echo $arrayname[0]
echo $cars[1]."<br>";

//Changing array iterms
//syntax
$acars[0] = 'Toyota';
echo $cars[0];

echo "I love $cars[0] , $cars[1] and $cars[2]";
echo "I love ".$cars[0]." , ".$cars[1]." and ".$cars[2]."<br>";

$larrength = count($cars);

#looping through an array indexed array
//use for loop for indexed array
for($x=0; $x < $arrlength; $x++){
    echo $cars[$x]."<br>";
}

































?>

