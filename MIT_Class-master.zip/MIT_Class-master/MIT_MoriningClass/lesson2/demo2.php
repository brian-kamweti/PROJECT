<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 6/3/19
 * Time: 9:43 AM
 */
#constants are like variables except that once they cannot be changed
#contant starts with aletter or underscore
#no $ sign before the constant name
#constant are global
#To define a constant use define()
#syntax
    //define(name, value, case-insensitive)

define("coordinates", 90, false);
echo coordinates;
ECHO "<br>";
define("height", 5.6, true);
echo height;
ECHO "<br>";
ECHO HEIGHT;
echo "<br>";
echo HEIGHT;
echo "<br>";
#Constant Arrays
//$fruits = array(["banana", "mango", "apple"]);
define("fruits",["Banana","mango", "apple"]);
echo fruits[0];
echo "<br>";
echo fruits[1];
echo "<br>";
echo fruits[2];


























?>

