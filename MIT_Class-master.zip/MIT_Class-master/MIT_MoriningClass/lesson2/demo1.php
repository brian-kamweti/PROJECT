<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 5/31/19
 * Time: 9:49 AM
 */
//Variables in php
//variables are containers for information
$name = "Antony";
echo $name;

$text = "Php is awesome";
echo $text;

$num1 = 100;
$num2 = 50;

echo $num1 + $num2;
# how to add html into php
echo "<header>
<h1>Welcome</h1>
</header>";

//php is loosely types
$float_number = 10.23; #floats are numbers that have decimal points
$integer_number = 1023;
$text = "Php is awesome";# a string - any text inclosed inside quotes is a string
$isHappy = false;# boolean
$isSad = true; #boolean

//Php varibale scope
//variables can be declared anywhere in php
//the scope of a variable is the part of the script
//where the variable can be used/refrenced
    #local
    #global
    #static

$x = 5; //global variable

function myText(){
    global $x;
    $sentence = "Welcome to php class";
    echo "Hello world $x";

}

myText();

#Php data types
//variables store diff types of data types
    #1. String
    #2. Integer
    #3. Float
    #4. Boolean
    #5. Array
    #6. Object
    #7. NULL
    #8. Resource

#Php String
$name = "Developer";
echo "<hr>";
var_dump($name);
echo "<br>";
echo strlen($name);
echo "<hr>";
echo str_word_count("Hello world!");
echo "<hr>";
echo strrev("Hello world");

echo str_replace("World", "Kenya", "Hello World");

$a = "Love for code <br>";
$b = "love for coffee";
echo $a.$b;

$d = date('Y');
echo $d;
echo "#######################<br>";
$x = 100;
echo "<br>";
echo $x++;
echo "<br>";
echo ++$x;





































?>