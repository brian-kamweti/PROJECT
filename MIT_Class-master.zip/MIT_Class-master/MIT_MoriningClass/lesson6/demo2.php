<?php
//PHP Sorting arrays
//The elements in an array can be sorted in alphabetical
//or numerical order, descending or ascending.
$cars = array('Benz','Vw','Toyota','Audi','Ford');
$nums = array(12,424,53,2,52,522,6634,423,23);
$food = array("Uganda"=>"Matoke","Kenya"=>"Sembe", "Tanzania"=>"Wali");

//sort(): sort array in ascending order
for ($x = 0 ; $x < count($cars); $x++){
    echo $x. $cars[$x]. "<br>";
}
sort($cars); # sorting the array in ascending order
sort($nums);
for ($x = 0 ; $x < count($cars); $x++){
    echo $x. $cars[$x]. "<br>";
}
//rsort() sort arrays in descending order
$cars = array('Benz','Vw','Toyota','Audi','Ford');
rsort($cars);
for ($x = 0 ; $x < count($cars); $x++){
    echo $x. $cars[$x]. "<br>";
}
//asort() sort associative array in ascending order,
// according to value
foreach($food as $country => $dish){
    echo "$country : $dish <br>";
}
asort($food);

foreach($food as $country => $dish){
    echo "$country : $dish <br>";
}
//ksort()sort associative arrays in ascending order
//acording to the key
ksort($food);
foreach($food as $country => $dish){
    echo "$country : $dish <br>";
}
ars




?>