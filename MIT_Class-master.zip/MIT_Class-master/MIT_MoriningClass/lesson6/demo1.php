<?php

//PHP arrays
//
//array()
//$variableName = array('benz', 'toyota')
# Indexed arrays
$cars = array('benz', 'toyota', 'audi', 'ford');
//$cars[0] == 'benz'
//$cars[1] == 'toyota'
echo $cars[0]."<br>";
echo $cars[2]."<br>";


echo "I like ".$cars[0]." ," .$cars[1] . " ,".$cars[2]. " and ". $cars[3];
$num_cars = count($cars);
//echo $num_cars;
echo count($cars);

//for (init count; test count;increment count){}
for ($x = 0; $x < $num_cars; $x++){
    echo $x.".".$cars[$x]."<br>";
}

#PHP Associative Arrays
#Associative arrays are arrays that use named keys that
# you assign to them.

$food = array("Uganda"=>"Matoke","Kenya"=>"Sembe", "Tanzania"=>"Wali");
echo $food["Uganda"];
echo "<br>";
//echo out "i love matoke, sembe and wali"

//foreach($food as $country=>$dish){
//    echo $country. "  ". $dish."<br>";
//}
$electronics = array();# empty array

$electronics['Phone'] = 'Huawei';
$electronics['laptop'] = 'yoga';
$electronics['TV'] = 'Samsung';

//foreach($electronics as $device=>$brand){
//    echo $device. "  ". $brand."<br>";
//}
//assignment: Create  two functions, one takes in an
// index array and the second one takes in an associative
// array as an argument and echos out each item.
function funIndex($theArray){
    for ($x = 0;$x < count($theArray); $x++){
        echo $x. $theArray[$x]."<br>";
    }
}
function funAssociative($theArray){
    foreach($theArray as $the_key =>$the_value){
        echo "Key :".$the_key ."=> Value :". $the_value. "<br>";
    }
}
funAssociative($food)










?>