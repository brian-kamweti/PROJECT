<?php

#Php condition statements
//1.if statement:Executes some code if ONE condition is true
//2.if...esle
//3.if ...elseif...else
//4.switch

/*
 if(condition){
    code to execute
}
 */
$gender = "Male";

if ($gender == "Female"){
    echo "happy womens' day";

}


if ($gender == "Female"){
    echo "happy womens' day";

}else{
    echo "Happy Mens' day";
}
echo "<br>";

if ($gender == "SomethingElse"){
    echo "happy womens' day";

}elseif($gender== "Other"){
    echo "Happy Others day";
}else{
    echo "You are not a human being , Maybe a BIGFOOT";
}
echo "<br>";
$t = date("H");
echo $t;

if ($t <= "12"){
    echo "good morming";
}elseif($t == "12"){
    echo "Good Afternoon";
}elseif ($t >= "12" and $t <= "17"){
    echo "Good evening";
}else{
    Echo "have a good day";
}
#goodmorning
#Goodafternoon
#goodevening
#have a good day
//Write a PHP program which iterates the integers from 1 to 100.
// For multiples of three print "Fizz" instead of the number
// and for the multiples of five print "Buzz".
// For numbers which are multiples of both three
// and five print "FizzBuzz".

# The switch statement is used to perform different
# actions based on different conditions.
//Use the switch statement to select one of many
// blocks of code to be executed.



//syntax
/*
switch(n){
    case label1:
        code to exexute;
        break;

    case label1:
            code to exexute;
            break;
    case label1:
            code to exexute;
            break;
    default:
        code to execute if n is different from labels;

}

*/
echo "<br>";
switch('Female'){
    case 'Male':
        echo 'I am a male';
        break;

    case 'Female':
        echo 'I am a female';
        break;

    case 'Other':
        echo 'I am a other';
        break;

    default:
        echo "Non of dthe above";




}















































?>