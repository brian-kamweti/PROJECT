<?php
//Besides the built-in PHP functions, we can create
// our own functions.
//
//A function is a block of statements that can
// be used repeatedly in a program.
//
//A function will not execute immediately when
// a page loads.
//
//A function will be executed by a call to the
// function.
/*
function functionName(){
    block of code to execute;
}

*/
#Creating/declaring a function
//function sayHelloWorld(){
//    echo "<br>";
//    echo "<br>";
//    echo "<br>";
//}
//#
////sayHelloWorld();#calling a function
//$x = strrev("Hello world");
////echo $x;
//# use a parameter when declaring a function
//function greetings($name, $age){
//    echo "My name is $name and my age is $age years old";
//}
//#use argument when calling a function
//$myName = "Antony";
//$myAge = 34;
//greetings($myName,$myAge);
//
//
//#create a function that takes a number, and it echos
//#out the square of that number.
//function getSquare($num){
//    echo $num * $num;
//}
//getSquare(10);

# Write a function to reverse a string.
function getMod($num, $num2){
    $result = $num % $num2;
    return $result;
}


$getTheMod = getMod(3, 2);
 function church($pastor= "Ng'anga"){
    echo "My pastor is Pst. $pastor";
 }

 church("Joseph");






















































?>