<?php
//Asigning constant variable to connect to the database
define('SERVERNAME','localhost');
define('USERNAME','root');
define('PASSWORD', '');
define('DB_NAME','mit_morning2');

//Create connection
$conn = mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DB_NAME);

//Check connection
if(!$conn){
    die("Connection failed".mysqli_connect_error());
}

//Create a called 'users' table
//SQL instruction to create a table
$sql = "CREATE TABLE users(
  id INT(6) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  firstname VARCHAR (30) NOT NULL,
  lastname VARCHAR (30) NOT NULL,
  email VARCHAR(60),
  password VARCHAR(100) NOT NULL ,
  time_reg TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP 
)";
//mysqli_query takes two arguments:
//    1.$conn - the path to the database with the correct cdredentials
//    2.$sql Instructions to the database| table schema
if(mysqli_query($conn,$sql)){
//    if the connection($conn) is successfull and the instructions to the database($sql) are
//    verifiable , users table will be creeated
    echo "Table users created successfully"."<br>";
}else{
//    if the connection is unsuccessfull or the instructions are not verifiable
    echo "Error creating the users table: ".mysqli_error($conn);
}

//adding a singe record
//$sql = "INSERT INTO users(firstname,lastname,email,password,time_reg)
//VALUES('tyMorgan','dfJeks','jecks@gmail.com','jecky', NULL )";

//Adding multiple records
//new record
//$sql = "INSERT INTO users(firstname,lastname,email,password,time_reg)
//VALUES('Nancy','TheDev','dev@gmail.com','jyhk', NULL );";
//
//
//$sql .= "INSERT INTO users (firstname, lastname, email,password,time_reg)
//VALUES ('Mary', 'Moe', 'mary@example.com', 'marrt',NULL)";
//new record
//$sql .= "INSERT INTO users(firstname,lastname,email,password,time_reg)
//VALUES('Beverly','Hotman','hot@gmail.com','thyjdty', NULL );";
//// new record
//$sql .= "INSERT INTO users(firstname,lastname,email,password,time_reg)
//VALUES('Sean','Roberts','jecks@gmail.com','yjtyj7tdk', NULL )";

if(mysqli_query($conn, $sql)){
//    Grabbing the id of the last added item
    $last_item = mysqli_insert_id($conn);
    echo "Record added successfully";
    echo "The record is $last_item";
}else{
    echo "Error: >>>". mysqli_error($conn);
}


#selecting data
#SELECT 'COLUMN' FROM 'TABLENAME'

#SELECT * FROM TABLENAME
$sql = "SELECT  id,firstname ,lastname FROM users";

$result = $conn->query($sql);

if($result->num_rows > 0 ){
    while($row = $result->fetch_assoc()){
        echo "id ".$row["id"]. "  ".$row['firstname']. "  ". $row['lastname'] ."<br>";
    }
}else{
    "O results";
}












mysqli_close($conn);

















?>

