<?php
$servername = 'localhost';
$username = 'root';
$password ='';

#creating connect
$conn = mysqli_connect($servername,$username,$password);

#check connection if successfull
if(!$conn){
    die("Connection failed: ".mysqli_connect_error());
}

#create databse
$sql = "CREATE DATABASE mit_morning2";
if (mysqli_query($conn, $sql)){
    echo "DB created successfully";
}else{
    echo "There was an error creating the database".mysqli_error($conn);
}
#close the connection
mysqli_close($conn);


?>