<?php
/**
 * Created by PhpStorm.
 * User: injila
 * Date: 6/3/19
 * Time: 10:36 AM
 */

#PHP operators
//1.Arithmetic operators
#Addition : +
#Subtraction:  -
#Multiplication :*
#Division : /
#Modulus :%
#Exponential: **

$x = 100;
$y = 7;
#addition
$z = $x + $y;
echo $z;
echo "<br>";
$a = $x % $y;
echo $a;

//Assignment Operators
#They are used to write a value to a variable
$s = 1;
$d = 3;
$s += 23;# $s = $s + 23;
$d -= 12;# $d = $d - 12;
$d *= 12;# $d = $d * 12;
$d = 12;
$d = 12;
$d = 12;

//PHP Comparison operators
$t = 1000000;
$r = 11000000;
//1.== equal
echo $r == $t;
//2.=== identical
#returns true if one variable is equal to another variable
//and they are of the same date types
$u = 100;# Integers
$l = 12.12;#float

echo "<br>";
var_dump($u === $l) ;#false
echo "<br>";
var_dump($u !=$l);#true
echo "<br>";
var_dump($u >=$l);#true
echo "<br>";
echo "<br>";
#Increament and Decreament Operators
#use them in conjuction with variables
//++ : Increament
//--: Decreament

$b = 0;
$c = 5;
echo ++$b;# 1 : Pre-increament,Increaments $b by one, then returns $b
echo "<br>";
echo $c++;#5 :Post-increament, returns $c,then increament $c by one
echo --$b;
echo $b--;

# Logical operators
//used to combine conditional statements
//1. and : $x and $c :True if both $x and $c are true
//2. or : $x or $c : True if either $x or $c is true
//3. xor: $x xor $c : True if either $x or $c is true but not both
//4. && :$x && $c :True if both $x and $c are true
//5.|| or : $x || $c : True if either $x or $y is true
//6. ! : !x :True if $x is not true
echo "<br>";
$x = "Male";
$y = "Female";
if($x == "Male" and $y == "Female"){
    ECHO "Condtions are true";
}
echo "<br>";
if($x == 99 or $y == 50){
    ECHO "One Condtions is not true";
}
echo "<br>";
if($x == 99 || $y == 50){
    ECHO "One Condtions is not true";
}
echo "<br>";
if(!$x ==100){
    ECHO "$x is not equal to 99";
}

# String Operators
//Concatenation
$name = "Php";
$name_two = "Developer";
echo $name.$name_two;
//Concatenation assignment
$firstname = "John";
$secondname ="Doe";
echo $firstname.=$secondname; #$firstname =$firstname.secondname













































?>